import { create } from 'zustand';
import { Role, User, Software, AccessRequest } from './types';

interface AuthState {
  user: User | null;
  login: (username: string, password: string) => Promise<void>;
  signup: (username: string, password: string) => Promise<void>;
  logout: () => void;
}

export const useAuthStore = create<AuthState>((set) => ({
  user: null,
  login: async (username, password) => {
    // Simulate API call
    const user: User = {
      id: '1',
      username,
      role: 'Employee' as Role,
    };
    set({ user });
  },
  signup: async (username, password) => {
    // Simulate API call
    const user: User = {
      id: '1',
      username,
      role: 'Employee' as Role,
    };
    set({ user });
  },
  logout: () => set({ user: null }),
}));

interface AppState {
  software: Software[];
  requests: AccessRequest[];
  addSoftware: (software: Omit<Software, 'id'>) => void;
  createRequest: (request: Omit<AccessRequest, 'id' | 'status'>) => void;
  updateRequestStatus: (requestId: string, status: 'Approved' | 'Rejected') => void;
}

export const useAppStore = create<AppState>((set) => ({
  software: [],
  requests: [],
  addSoftware: (newSoftware) => 
    set((state) => ({
      software: [...state.software, { ...newSoftware, id: Date.now().toString() }],
    })),
  createRequest: (newRequest) =>
    set((state) => ({
      requests: [
        ...state.requests,
        { ...newRequest, id: Date.now().toString(), status: 'Pending' },
      ],
    })),
  updateRequestStatus: (requestId, status) =>
    set((state) => ({
      requests: state.requests.map((request) =>
        request.id === requestId ? { ...request, status } : request
      ),
    })),
}));