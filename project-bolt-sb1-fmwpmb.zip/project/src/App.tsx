import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { LoginForm } from './components/auth/LoginForm';
import { SignUpForm } from './components/auth/SignUpForm';
import { useAuthStore } from './lib/store';

function PrivateRoute({ children }: { children: React.ReactNode }) {
  const user = useAuthStore((state) => state.user);
  return user ? <>{children}</> : <Navigate to="/login" />;
}

function App() {
  return (
    <Router>
      <div className="min-h-screen bg-gray-100">
        <div className="container mx-auto px-4 py-8">
          <Routes>
            <Route path="/login" element={
              <div className="max-w-md mx-auto bg-white p-8 rounded-lg shadow-md">
                <h1 className="text-2xl font-bold mb-6">Login</h1>
                <LoginForm />
              </div>
            } />
            <Route path="/signup" element={
              <div className="max-w-md mx-auto bg-white p-8 rounded-lg shadow-md">
                <h1 className="text-2xl font-bold mb-6">Sign Up</h1>
                <SignUpForm />
              </div>
            } />
            <Route path="/dashboard" element={
              <PrivateRoute>
                <div className="max-w-4xl mx-auto bg-white p-8 rounded-lg shadow-md">
                  <h1 className="text-2xl font-bold mb-6">Dashboard</h1>
                  {/* Dashboard content will be added later */}
                </div>
              </PrivateRoute>
            } />
            <Route path="/" element={<Navigate to="/login" />} />
          </Routes>
        </div>
      </div>
    </Router>
  );
}

export default App;