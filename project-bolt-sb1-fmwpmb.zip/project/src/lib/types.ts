export type Role = 'Employee' | 'Manager' | 'Admin';
export type AccessLevel = 'Read' | 'Write' | 'Admin';
export type RequestStatus = 'Pending' | 'Approved' | 'Rejected';

export interface User {
  id: string;
  username: string;
  role: Role;
}

export interface Software {
  id: string;
  name: string;
  description: string;
  accessLevels: AccessLevel[];
}

export interface AccessRequest {
  id: string;
  userId: string;
  softwareId: string;
  accessType: AccessLevel;
  reason: string;
  status: RequestStatus;
  username?: string;
  softwareName?: string;
}